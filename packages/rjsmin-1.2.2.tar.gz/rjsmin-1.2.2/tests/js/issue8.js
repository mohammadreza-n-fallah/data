if (1) console.log(`  space {kla;gk;skgld}
    x
moar.
`)
