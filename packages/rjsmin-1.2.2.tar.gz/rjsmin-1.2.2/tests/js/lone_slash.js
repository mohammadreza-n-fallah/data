foo =~ /
