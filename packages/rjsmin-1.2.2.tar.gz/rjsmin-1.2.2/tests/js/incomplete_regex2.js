var x= /lal  +   ala[la/

!Ha
