var a='s  t"ring';b="an\"oth\xe9r  \
str\ting    ";f="string with CRLF \
some more  ";if(/[som\]e ]re   \dgex/.match('a')){x=/abc//*! lolo */
if(1)console.log(x);c=a++ + ++b;d=a-- - --b;e=a/b;}
return/*!lalala */
/blahr/