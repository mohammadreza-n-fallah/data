import sql_server.pyodbc.functions  # noqa
